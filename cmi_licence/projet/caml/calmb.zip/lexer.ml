#open "obj";;
#open "lexing";;


print_string "debut module lexer\n";flush std_out;;

#open "parser";;
#open "excep";;

print_string "module lexer\n";flush std_out;;


let rec action_16 lexbuf = ((
 failwith ("caractere inconnu:"^(get_lexeme lexbuf)) ) : 'Token)
and action_15 lexbuf = ((
 raise Eof ) : 'Token)
and action_14 lexbuf = ((
 FIN_EXP ) : 'Token)
and action_13 lexbuf = ((
 VIRGULE ) : 'Token)
and action_12 lexbuf = ((
 PARENTD ) : 'Token)
and action_11 lexbuf = ((
 PARENTG ) : 'Token)
and action_10 lexbuf = ((
 DIV ) : 'Token)
and action_9 lexbuf = ((
 FOIS ) : 'Token)
and action_8 lexbuf = ((
 MOINS ) : 'Token)
and action_7 lexbuf = ((
 PLUS ) : 'Token)
and action_6 lexbuf = ((
 ID(get_lexeme lexbuf) ) : 'Token)
and action_5 lexbuf = ((
 LOG ) : 'Token)
and action_4 lexbuf = ((
 SIN ) : 'Token)
and action_3 lexbuf = ((
 VAL(float_of_string(get_lexeme lexbuf)) ) : 'Token)
and action_2 lexbuf = ((
 VAL(float_of_string(get_lexeme lexbuf)) ) : 'Token)
and action_1 lexbuf = ((
 VAL(float_of_string(get_lexeme lexbuf)) ) : 'Token)
and action_0 lexbuf = ((
 Token lexbuf ) : 'Token)
and state_0 lexbuf =
  match get_next_char lexbuf with
    `z`|`y`|`x`|`w`|`v`|`u`|`t`|`r`|`q`|`p`|`o`|`n`|`m`|`k`|`j`|`i`|`h`|`g`|`f`|`e`|`d`|`c`|`b`|`a`|`Z`|`Y`|`X`|`W`|`V`|`U`|`T`|`S`|`R`|`Q`|`P`|`O`|`N`|`M`|`L`|`K`|`J`|`I`|`H`|`G`|`F`|`E`|`D`|`C`|`B`|`A` -> state_14 lexbuf
 |  `9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_12 lexbuf
 |  ` `|`\010`|`\t` -> action_0 lexbuf
 |  `s` -> state_16 lexbuf
 |  `l` -> state_15 lexbuf
 |  `;` -> action_14 lexbuf
 |  `/` -> action_10 lexbuf
 |  `.` -> state_10 lexbuf
 |  `-` -> action_8 lexbuf
 |  `,` -> action_13 lexbuf
 |  `+` -> action_7 lexbuf
 |  `*` -> action_9 lexbuf
 |  `)` -> action_12 lexbuf
 |  `(` -> action_11 lexbuf
 |  `\000` -> action_15 lexbuf
 |  _ -> action_16 lexbuf
and state_10 lexbuf =
  lexbuf.lex_last_pos <- lexbuf.lex_curr_pos;
  lexbuf.lex_last_action <- magic action_2;
  match get_next_char lexbuf with
    `9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_24 lexbuf
 |  _ -> backtrack lexbuf
and state_12 lexbuf =
  lexbuf.lex_last_pos <- lexbuf.lex_curr_pos;
  lexbuf.lex_last_action <- magic action_3;
  match get_next_char lexbuf with
    `9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_23 lexbuf
 |  `.` -> state_22 lexbuf
 |  _ -> backtrack lexbuf
and state_14 lexbuf =
  lexbuf.lex_last_pos <- lexbuf.lex_curr_pos;
  lexbuf.lex_last_action <- magic action_6;
  match get_next_char lexbuf with
    `z`|`y`|`x`|`w`|`v`|`u`|`t`|`s`|`r`|`q`|`p`|`o`|`n`|`m`|`l`|`k`|`j`|`i`|`h`|`g`|`f`|`e`|`d`|`c`|`b`|`a`|`_`|`Z`|`Y`|`X`|`W`|`V`|`U`|`T`|`S`|`R`|`Q`|`P`|`O`|`N`|`M`|`L`|`K`|`J`|`I`|`H`|`G`|`F`|`E`|`D`|`C`|`B`|`A`|`9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_17 lexbuf
 |  _ -> backtrack lexbuf
and state_15 lexbuf =
  lexbuf.lex_last_pos <- lexbuf.lex_curr_pos;
  lexbuf.lex_last_action <- magic action_6;
  match get_next_char lexbuf with
    `z`|`y`|`x`|`w`|`v`|`u`|`t`|`s`|`r`|`q`|`p`|`n`|`m`|`l`|`k`|`j`|`i`|`h`|`g`|`f`|`e`|`d`|`c`|`b`|`a`|`_`|`Z`|`Y`|`X`|`W`|`V`|`U`|`T`|`S`|`R`|`Q`|`P`|`O`|`N`|`M`|`L`|`K`|`J`|`I`|`H`|`G`|`F`|`E`|`D`|`C`|`B`|`A`|`9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_17 lexbuf
 |  `o` -> state_20 lexbuf
 |  _ -> backtrack lexbuf
and state_16 lexbuf =
  lexbuf.lex_last_pos <- lexbuf.lex_curr_pos;
  lexbuf.lex_last_action <- magic action_6;
  match get_next_char lexbuf with
    `z`|`y`|`x`|`w`|`v`|`u`|`t`|`s`|`r`|`q`|`p`|`o`|`n`|`m`|`l`|`k`|`j`|`h`|`g`|`f`|`e`|`d`|`c`|`b`|`a`|`_`|`Z`|`Y`|`X`|`W`|`V`|`U`|`T`|`S`|`R`|`Q`|`P`|`O`|`N`|`M`|`L`|`K`|`J`|`I`|`H`|`G`|`F`|`E`|`D`|`C`|`B`|`A`|`9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_17 lexbuf
 |  `i` -> state_18 lexbuf
 |  _ -> backtrack lexbuf
and state_17 lexbuf =
  lexbuf.lex_last_pos <- lexbuf.lex_curr_pos;
  lexbuf.lex_last_action <- magic action_6;
  match get_next_char lexbuf with
    `z`|`y`|`x`|`w`|`v`|`u`|`t`|`s`|`r`|`q`|`p`|`o`|`n`|`m`|`l`|`k`|`j`|`i`|`h`|`g`|`f`|`e`|`d`|`c`|`b`|`a`|`_`|`Z`|`Y`|`X`|`W`|`V`|`U`|`T`|`S`|`R`|`Q`|`P`|`O`|`N`|`M`|`L`|`K`|`J`|`I`|`H`|`G`|`F`|`E`|`D`|`C`|`B`|`A`|`9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_17 lexbuf
 |  _ -> backtrack lexbuf
and state_18 lexbuf =
  lexbuf.lex_last_pos <- lexbuf.lex_curr_pos;
  lexbuf.lex_last_action <- magic action_6;
  match get_next_char lexbuf with
    `z`|`y`|`x`|`w`|`v`|`u`|`t`|`s`|`r`|`q`|`p`|`o`|`m`|`l`|`k`|`j`|`i`|`h`|`g`|`f`|`e`|`d`|`c`|`b`|`a`|`_`|`Z`|`Y`|`X`|`W`|`V`|`U`|`T`|`S`|`R`|`Q`|`P`|`O`|`N`|`M`|`L`|`K`|`J`|`I`|`H`|`G`|`F`|`E`|`D`|`C`|`B`|`A`|`9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_17 lexbuf
 |  `n` -> state_19 lexbuf
 |  _ -> backtrack lexbuf
and state_19 lexbuf =
  lexbuf.lex_last_pos <- lexbuf.lex_curr_pos;
  lexbuf.lex_last_action <- magic action_4;
  match get_next_char lexbuf with
    `z`|`y`|`x`|`w`|`v`|`u`|`t`|`s`|`r`|`q`|`p`|`o`|`n`|`m`|`l`|`k`|`j`|`i`|`h`|`g`|`f`|`e`|`d`|`c`|`b`|`a`|`_`|`Z`|`Y`|`X`|`W`|`V`|`U`|`T`|`S`|`R`|`Q`|`P`|`O`|`N`|`M`|`L`|`K`|`J`|`I`|`H`|`G`|`F`|`E`|`D`|`C`|`B`|`A`|`9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_17 lexbuf
 |  _ -> backtrack lexbuf
and state_20 lexbuf =
  lexbuf.lex_last_pos <- lexbuf.lex_curr_pos;
  lexbuf.lex_last_action <- magic action_6;
  match get_next_char lexbuf with
    `z`|`y`|`x`|`w`|`v`|`u`|`t`|`s`|`r`|`q`|`p`|`o`|`n`|`m`|`l`|`k`|`j`|`i`|`h`|`f`|`e`|`d`|`c`|`b`|`a`|`_`|`Z`|`Y`|`X`|`W`|`V`|`U`|`T`|`S`|`R`|`Q`|`P`|`O`|`N`|`M`|`L`|`K`|`J`|`I`|`H`|`G`|`F`|`E`|`D`|`C`|`B`|`A`|`9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_17 lexbuf
 |  `g` -> state_21 lexbuf
 |  _ -> backtrack lexbuf
and state_21 lexbuf =
  lexbuf.lex_last_pos <- lexbuf.lex_curr_pos;
  lexbuf.lex_last_action <- magic action_5;
  match get_next_char lexbuf with
    `z`|`y`|`x`|`w`|`v`|`u`|`t`|`s`|`r`|`q`|`p`|`o`|`n`|`m`|`l`|`k`|`j`|`i`|`h`|`g`|`f`|`e`|`d`|`c`|`b`|`a`|`_`|`Z`|`Y`|`X`|`W`|`V`|`U`|`T`|`S`|`R`|`Q`|`P`|`O`|`N`|`M`|`L`|`K`|`J`|`I`|`H`|`G`|`F`|`E`|`D`|`C`|`B`|`A`|`9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_17 lexbuf
 |  _ -> backtrack lexbuf
and state_22 lexbuf =
  lexbuf.lex_last_pos <- lexbuf.lex_curr_pos;
  lexbuf.lex_last_action <- magic action_1;
  match get_next_char lexbuf with
    `9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_22 lexbuf
 |  _ -> backtrack lexbuf
and state_23 lexbuf =
  lexbuf.lex_last_pos <- lexbuf.lex_curr_pos;
  lexbuf.lex_last_action <- magic action_3;
  match get_next_char lexbuf with
    `9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_23 lexbuf
 |  `.` -> state_22 lexbuf
 |  _ -> backtrack lexbuf
and state_24 lexbuf =
  lexbuf.lex_last_pos <- lexbuf.lex_curr_pos;
  lexbuf.lex_last_action <- magic action_2;
  match get_next_char lexbuf with
    `9`|`8`|`7`|`6`|`5`|`4`|`3`|`2`|`1`|`0` -> state_24 lexbuf
 |  _ -> backtrack lexbuf
and Token lexbuf =
  start_lexing lexbuf;
  (state_0 lexbuf : 'Token)
;;
