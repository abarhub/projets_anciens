#open "obj";;
#open "parsing";;
#open "arbre";;

print_string "module parser\n";flush std_out;;

(* Line 8, file parser.ml *)
let yytransl = [|
  257 (* VAL *);
  258 (* ID *);
  259 (* PLUS *);
  260 (* MOINS *);
  261 (* FOIS *);
  262 (* DIV *);
  263 (* MOINSU *);
  264 (* EOL *);
  265 (* PARENTG *);
  266 (* PARENTD *);
  267 (* SIN *);
  268 (* LOG *);
  269 (* FIN_EXP *);
  270 (* VIRGULE *);
    0|];;

let yylhs = "\255\255\
\001\000\002\000\003\000\003\000\003\000\003\000\003\000\003\000\
\003\000\003\000\003\000\000\000";;

let yylen = "\002\000\
\001\000\004\000\001\000\003\000\003\000\003\000\003\000\003\000\
\002\000\002\000\001\000\002\000";;

let yydefred = "\000\000\
\000\000\000\000\003\000\011\000\000\000\000\000\000\000\012\000\
\001\000\000\000\010\000\009\000\000\000\000\000\000\000\000\000\
\000\000\000\000\004\000\000\000\000\000\007\000\008\000\000\000\
\002\000";;

let yydgoto = "\002\000\
\008\000\009\000\010\000";;

let yysindex = "\012\000\
\028\255\000\000\000\000\000\000\028\255\028\255\028\255\000\000\
\000\000\000\255\000\000\000\000\030\255\028\255\028\255\028\255\
\028\255\017\255\000\000\002\255\002\255\000\000\000\000\007\255\
\000\000";;

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\012\255\014\255\000\000\000\000\000\000\
\000\000";;

let yygindex = "\000\000\
\000\000\000\000\251\255";;

let YYTABLESIZE = 40;;
let yytable = "\011\000\
\012\000\013\000\014\000\015\000\016\000\017\000\016\000\017\000\
\020\000\021\000\022\000\023\000\001\000\018\000\005\000\005\000\
\006\000\006\000\024\000\025\000\000\000\005\000\000\000\006\000\
\000\000\005\000\000\000\006\000\003\000\004\000\005\000\006\000\
\014\000\015\000\016\000\017\000\007\000\000\000\000\000\019\000";;

let yycheck = "\005\000\
\006\000\007\000\003\001\004\001\005\001\006\001\005\001\006\001\
\014\000\015\000\016\000\017\000\001\000\014\001\003\001\004\001\
\003\001\004\001\002\001\013\001\255\255\010\001\255\255\010\001\
\255\255\014\001\255\255\014\001\001\001\002\001\003\001\004\001\
\003\001\004\001\005\001\006\001\009\001\255\255\255\255\010\001";;

let yyact = [|
  (fun () -> failwith "parser")
(* Rule 1, file parser.mly, line 26 *)
; (fun () -> repr(( (peek_val 0 : 'Ligne) ) : arbre__arbre))
(* Rule 2, file parser.mly, line 30 *)
; (fun () -> repr(( Arbre((peek_val 3 : 'Exp),(peek_val 1 : string)) ) : 'Ligne))
(* Rule 3, file parser.mly, line 34 *)
; (fun () -> repr(( Flotant((peek_val 0 : float)) ) : 'Exp))
(* Rule 4, file parser.mly, line 35 *)
; (fun () -> repr(( (peek_val 1 : 'Exp) ) : 'Exp))
(* Rule 5, file parser.mly, line 36 *)
; (fun () -> repr(( Plus((peek_val 2 : 'Exp),(peek_val 0 : 'Exp)) ) : 'Exp))
(* Rule 6, file parser.mly, line 37 *)
; (fun () -> repr(( Moins((peek_val 2 : 'Exp),(peek_val 0 : 'Exp)) ) : 'Exp))
(* Rule 7, file parser.mly, line 38 *)
; (fun () -> repr(( Fois((peek_val 2 : 'Exp),(peek_val 0 : 'Exp)) ) : 'Exp))
(* Rule 8, file parser.mly, line 39 *)
; (fun () -> repr(( Div((peek_val 2 : 'Exp),(peek_val 0 : 'Exp)) ) : 'Exp))
(* Rule 9, file parser.mly, line 41 *)
; (fun () -> repr(( Moins_u((peek_val 0 : 'Exp)) ) : 'Exp))
(* Rule 10, file parser.mly, line 43 *)
; (fun () -> repr(( Plus_u((peek_val 0 : 'Exp)) ) : 'Exp))
(* Rule 11, file parser.mly, line 44 *)
; (fun () -> repr(( Var((peek_val 0 : string)) ) : 'Exp))
(* Entry Main *)
; (fun () -> raise (yyexit (peek_val 0)))
|];;
let yytables =
  { actions=yyact;
    transl=yytransl;
    lhs=yylhs;
    len=yylen;
    defred=yydefred;
    dgoto=yydgoto;
    sindex=yysindex;
    rindex=yyrindex;
    gindex=yygindex;
    tablesize=YYTABLESIZE;
    table=yytable;
    check=yycheck };;
let Main lexfun lexbuf = yyparse yytables 1 lexfun lexbuf;;
